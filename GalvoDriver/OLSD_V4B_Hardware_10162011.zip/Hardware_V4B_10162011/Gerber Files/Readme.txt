Gerber Files produced by Eagle Lite V5.11
Using the CAM file:  http://www.sparkfun.com/tutorial/BeginningEmbedded/9-EaglePCBs/sfe-gerb274x.cam
Files are in the Gerber RS274X format

* Top and bottom copper (.GTL, .GBL)
* Top and bottom solder mask (.GTS, .GBS)
* Top and bottom silkscreen (.GTO, .GBO)
* Drill file, 2.4 leading (.TXT)
